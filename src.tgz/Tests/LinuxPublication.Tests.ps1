BeforeDiscovery {
    . (Join-Path $PSScriptRoot 'TestHelpers.ps1')
    Import-PASTestModule
}
Describe 'Linux same-boot durable publication' {
    InModuleScope PASeasyInstall {
        It 'publishes staged boot and flushes filesystems before first start' {
            $script:PublicationCalls = New-Object Collections.ArrayList
            Mock Invoke-PASRawSSH { return @{ExitCode = 0; Output = '' } }
            Mock Invoke-PASLinuxControl {
                param($Target, $Command)
                [void]$script:PublicationCalls.Add($Command)
                return ''
            }
            Mock Copy-PASRawSSH {}
            Mock Start-PASLinuxDetached { [void]$script:PublicationCalls.Add('START') }
            $task = [IO.Path]::GetTempFileName()
            try {
                [IO.File]::WriteAllText($task, 'echo fixture')
                $null = Initialize-PASLinuxDetached @{User = 'root' } $task @{Fixture = 'nonsecret' } ('a' * 32) 60 Object
                $publish = @($script:PublicationCalls | Where-Object { $_ -like '*stagedBootId*' })
                $publish.Count | Should -Be 1
                $publish[0] | Should -Match 'attemptId:\$id,stagedBootId:\$boot'
                $publish[0] |
                    Should -Match 'sync -f /opt/paeasyinstall/attempts/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa; sync -f /etc/systemd/system'
                $script:PublicationCalls.IndexOf($publish[0]) | Should -BeLessThan $script:PublicationCalls.IndexOf('START')
                @($script:PublicationCalls | Where-Object { $_ -like '*command -v sync*sync -f /opt*' }).Count | Should -Be 1
            } finally { Remove-Item $task -Force -ErrorAction SilentlyContinue }
        }
        It 'repeats required filesystem barriers before a resumed same-attempt start' {
            $script:ResumeStartCommand = ''
            Mock Invoke-PASLinuxControl {
                param($Target, $Command)
                $script:ResumeStartCommand = $Command
                return ''
            }
            Start-PASLinuxDetached @{} ('b' * 32)
            $script:ResumeStartCommand |
                Should -Match 'sync -f /opt/paeasyinstall/attempts/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb; sync -f /etc/systemd/system; systemctl daemon-reload; systemctl start'
        }
    }
}
